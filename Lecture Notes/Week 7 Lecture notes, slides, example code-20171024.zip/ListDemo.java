public class ListDemo {
	public static void main(String[] args) {
		ListInterface<String> strList = new AList<String>();
		Scanner keyboard = new Scanner(System.in);
		while(true) {
			String curr = keyboard.next();
			if(curr.equals(�quit�)) { break; }
			else {
				strList.add(curr);
		}
	}
System.out.println(�# of items in list: �+strList.getLength());
System.out.println(�3rd element: �+strList.getEntry(2));
System.out.println(�list: �);
strList.display();

}
}
