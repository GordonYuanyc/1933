import java.util.Arrays;
import java.util.Scanner;
import java.util.Random;


public class Main {

    public static void main(String[] args) {
        Circle[] circleArray = new Circle[100];
        if (circleArray[0] == null) {
            System.out.println("Elements are null!");
        }

        for (int i = 0; i < circleArray.length; i++) {
            circleArray[i] = new Circle(i, 0, 0);
        }

        int[] intArray = new int[100];

        for (int i = 0; i < intArray.length; i++) {
            intArray[i] = -1;
        }

        System.out.println("Before update:");
        System.out.println("X:" + circleArray[0].getXPos() + "  Y:" + circleArray[0].getYPos());
        System.out.println("0: " + intArray[0] + "  1: " + intArray[1]);

        updateCircles(circleArray);
        updateInts(intArray);



        System.out.println("After update:");
        System.out.println("X:" + circleArray[0].getXPos() + "  Y:" + circleArray[0].getYPos());
        System.out.println("0: " + intArray[0] + "  1: " + intArray[1]);


        multiDimArrayDemo();
        arrayOpsDemo();
    }




    public static void updateInts(int[] array) {
        for(int i=0; i < array.length; i++) {
            int j = array[i];
            j++;
        }
    }

    public static void updateCircles(Circle[] array) {
        for(int i=0; i < array.length; i++) {
            Circle c = array[i];
            c.setPos((int)c.getXPos(),(int)c.getYPos()+100);
        }
    }



    public static Circle[] resize(Circle[] array, int count) {
        Circle[] newArray = new Circle[count];
        for(int i=0; i < count; i++) {
            newArray[i] = array[i];
        }
        return newArray;
    }



    public static void resizeDemo() {

        Circle[] circleArray = new Circle[10];
        int count=0;
        Scanner keyboard = new Scanner(System.in);
        while(count < 10) {
            System.out.println("Enter radius or ‘N’ to quit:");

            if(keyboard.hasNextInt()) {
                circleArray[count++] = new Circle(0,0,keyboard.nextInt());
            } else { break; }
        }
        //how can we resize this array?
        System.out.println("Finished demo");
    }


    public static void multiDimArrayDemo() {

        double[][] grades = new double[120][6];
        for(int i=0; i < 120; i++) {
            for(int j=0; j < 6; j++) {
                grades[i][j]=100;
            }
        }


        System.out.println(grades.length);
        System.out.println(grades[0].length);

    }



    public static void arrayOpsDemo() {
        int[] numArray = new int[100];

        Random randomNumGenerator = new Random();
        for (int i = 0; i < numArray.length; i++) {
            numArray[i] = randomNumGenerator.nextInt(100);
        }

        System.out.println("Original:");
        System.out.println(Arrays.toString(numArray));

        System.out.println("Sorted:");
        Arrays.sort(numArray);
        System.out.println(Arrays.toString(numArray));

        int result = Arrays.binarySearch(numArray, 5);  //Must be sorted first!!
        if (result > 0) {
            System.out.println("Found!  Index:" + result);
        } else {
            System.out.println("Not found!  Index:" + result);
        }
    }
}
