import java.util.Scanner;
import java.io.*;

public class JavaDemoClass {

	public JavaDemoClass() {
		
	}
	
	public static void main(String[] args) {
		FileReader seqFile = new FileReader();
		
		String sequence = seqFile.readSequenceFromFile("yeast_chr16_genomesequence.txt");
		System.out.println(sequence);
	
		try {
		sequence = seqFile.readSequenceFromFileVer2("yeast_chr16_genomesequence.txt");
		System.out.println(sequence);
		} catch(FileNotFoundException e) {
			System.out.println("Sorry, can't find file!"); 
			System.out.println(e.getMessage()); 
			System.exit(1); 
		}
	
	}
	
	
	
}
