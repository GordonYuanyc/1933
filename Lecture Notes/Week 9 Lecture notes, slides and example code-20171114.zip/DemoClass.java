import java.util.Stack;
 
public class DemoClass {
   
    public static void main(String[] args) {
    	
 	
		    System.out.println(reverseNumber(456));

		    System.out.println(reverseString("test string"));
        
        
       
    }
 
        
    public static String reverseString(String str) {
        Stack<Character> st = new Stack<Character>();
         
        // Push all characters of string 
        // to stack
        char[] chars = str.toCharArray();
        String rev = "";
        
        for(char c:chars) {
        	st.push(c);
        }
        
		while(!st.isEmpty()) { rev += st.pop(); }
        
		return rev;
	}
	
	
	// Function to reverse the number
    public static int reverseNumber(int number)
    {
 
        Stack<Integer> st= new Stack<>();
        
        while(number != 0) {
            st.push(number % 10);
            number = number / 10;
        }
        
        int reverse = 0;
        int i = 1;
 
        // Popping the digits and forming
        // the reversed number
        while (!st.isEmpty()) {
            reverse = reverse + (st.pop() * i);
            i = i * 10;
        }
 
        // Return the reversed number formed
        return reverse;
    }
}