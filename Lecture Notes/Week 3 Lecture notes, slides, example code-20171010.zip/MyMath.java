public class MyMath {
private double count=0;
private double x=100;

public double factorial(double x) {
double result=1;

for(double i=1; i <= x; i++) {
	result *= i; }
count++;
return result;
}

public double linearFunction(double m, double b, double x) {
		double result=0;
		result = m*x+b;

		System.out.println("x:"+ x +" this.x=" + this.x);
		x=3; 
		System.out.println("x:"+ x + " this.x=" + this.x);

		count++;
		return result;

}


public double getNumCalls() {
		return count;
}


	
public static void main(String[] args) {
	MyMath calculator = new MyMath();

	double result = calculator.linearFunction(10,0,1);
	System.out.println("result="+result);
	
	double sum=0;
	for(int i=1; i < 100; i++) {
		sum += calculator.factorial(i);
	}
	System.out.println("NumCalls="+calculator.getNumCalls());

}
}

