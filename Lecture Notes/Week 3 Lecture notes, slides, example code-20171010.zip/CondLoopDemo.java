import java.util.Scanner;

public class CondLoopDemo {

	public static void main(String[] args) {
		condDemo();
		loopDemo();
		loopExample();
		compareFactorials();
		
		//a^b-XOR
		
		//&&-AND
		//||-OR
	}
	
	
	public static void condDemo() {
		System.out.println("Conditionals demos");
		
		int testscore = 70; 

		if (testscore >= 90) { 
			System.out.println("Grade = at least A"); 
		} 
		else if (testscore >= 80) { 
			System.out.println("Grade = at least B"); 
		} 
		else if (testscore >= 70) { 
			System.out.println("Grade = at least C"); 
		} 
		else if (testscore >= 60) { 
			System.out.println("Grade = at least D"); 
		} 
		else { 
			System.out.println("Grade = F"); 
		} 

		System.out.println("Example 2:");
		testscore = 70; 

		if (testscore >= 90) { 
			System.out.println("Grade = at least A"); 
		} 
		if (testscore >= 80) { 
			System.out.println("Grade = at least B"); 
		} 

		if (testscore >= 70) { 
			System.out.println("Grade = at least C"); 
		} 

		if (testscore >= 60) { 
			System.out.println("Grade = at least D"); 
		} 
		else { 
			System.out.println("Grade = F"); 
		} 

		System.out.println("Example 3:");

		int i=1;
		while(i==1) { System.out.println("i:"+i); i++; }
		
		
	}
	
	public static void loopDemo() {
		System.out.println("Loop demos");

		int number = 10;
		int count = 1;
		while (count <= number)
		{
		  System.out.println(count);
		  count++;
		} // end while
		
		
		number = 10;
		for (count=0; count < number; count+=2) {
			System.out.println("For:"+count);
		}

		
		number = 10;
		for (count=10; count > 0; count--) {
			System.out.println("For:"+ count);
		}
		
		number=1;
		count=1;
		do
		{
		System.out.println("Do-while:"+count);
		count++;
		} while(count <= number);

		
		System.out.println("Square calculator:");
		Scanner keyboard = new Scanner(System.in);
		int i=0;
		while(true) {
			System.out.println("Enter a number:");
			if(keyboard.hasNextInt()) {
				int currInt = keyboard.nextInt();
				System.out.println("Square = "+(currInt*currInt));
			}
			else {
				System.out.println("Sorry, you didn�t enter a number�-GAME OVER!");
				break;
			}
		}
		
		System.out.println();

		System.out.println("Continue example");
		int j,sum=0;

		for(j =0; j < 20; j++) {
			if(j%2 == 1) { 
				continue; 
			}
			System.out.println("Adding "+j);
			sum += j;
		}

		//Nested loops
		//Multiplication table example
		System.out.print("\t");
		for(i=1; i <= 8; i++) {
			System.out.print(i+"\t");
			}
		System.out.println();
		
		for(i=1; i <= 8; i++) {
			System.out.print(i+"\t");	
			for(j=1; j<=8; j++) {
				System.out.print((i*j)+"\t");	
			}
			System.out.println();	
		}


		//rectangle example
		int width = 50;
		int height = 5;

		for(int m=0; m<height; m++)
		{
			for(int n=0; n<width;n++) {
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
		System.out.println();
			
		//triangle example
		int num = 20;
		
		for(int m=0; m<num; m++)
		{
			for(int n=0; n < m; n++) {
				System.out.print("*");
				System.out.print("*");
			}
			System.out.println();
		}
		for(int m=num; m>0;m--)
		{
			for(int n=0; n < m;n++) {
				System.out.print("*");
				System.out.print("*");
			}
			System.out.println();
		}
			
	
	}
	
	public static void loopExample() {
		int sum=0;
		int num = 2;

		while (num < 10) {
			sum += num;
			num += 2; 
		}
		System.out.println("Sum: "+sum);
		System.out.println("num: "+num);
	}
	
	
	public static void compareFactorials() { 
		System.out.println("Comparing factorials");
		int x=150;
		int N=10000000;
		
		System.out.println("Running loop version...");
		long starttime = System.currentTimeMillis();
		double result1=0;
		for(int i=0; i < N; i++) {
			result1=loopFactorial(x);
		}			
		long endtime = System.currentTimeMillis();
		System.out.println("Loop version: result="+result1+", Time="+(endtime-starttime) +" milliseconds");
		
		
		System.out.println("Running recursive version...");		
		starttime = System.currentTimeMillis();
		double result2=0;
		for(int i=0; i < N; i++) {
			result2=recurseFactorial(x);
		}		
		endtime = System.currentTimeMillis();	
		System.out.println("Recursive version: result="+result2+", Time="+(endtime-starttime)+" milliseconds");
	}
	
	
		
	
	public static double loopFactorial(int x) {
		double result=1;
		
		for(int i=1; i <= x; i++) {
			result *= i;
		}

		return result;
	}
	
	
	
	public static double recurseFactorial(int x) {
		
		double result;
		if(x <= 1) { result=1;}
		else {
			result = x*recurseFactorial(x-1);	
		}
		return result;
	}
	
	
	
}