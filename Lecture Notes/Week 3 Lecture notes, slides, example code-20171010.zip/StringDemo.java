import java.util.StringTokenizer;


public class StringDemo {

	public static void main(String[] args) {
		String className = new String("UMN:CSCI:1933:Sec001");
		String className2 = "UMN:CSCI:1933:Sec001";  //this also works
		
		System.out.println(className);
		
		System.out.println("1st try:");
		String str1 = new String("string1");
		String str2 = new String("string1");
		
		if(str1 == str2) { System.out.println("Strings are equal!"); }
		else { System.out.println("Strings not equal!");}

		System.out.println("2nd try:");
		str1 = new String("string1");
		str2 = new String("string2");
		str1 = str2;
		
		if(str1 == str2) { System.out.println("Strings are equal!"); }
		else { System.out.println("Strings not equal!");}
		
		
		System.out.println("3rd try:");
		str1 = new String("string1");
		str2 = new String("string1");
		
		if(str1.equals(str2)) { System.out.println("Strings are equal!"); }
		else { System.out.println("Strings not equal!");}
		
		
		
		System.out.println("String comparison");
		String letterA = new String("A");
		String lettera = new String("a");
		String letterb = new String("b");
		
		System.out.println(letterA.compareTo(letterb));
		System.out.println(lettera.compareTo(letterA));

		
		className = new String("UMN:CSCI:1933:Sec001");
		System.out.println(className.indexOf("CSCI"));
		System.out.println(className.indexOf(":",4));
		
		//String concatenation
		str1 = "string1";
		str2 = "string2";
		
		str1 = str1 + str2;
		System.out.println("Concatenated strings:"+str1);	
		str1 += str2;
		System.out.println("Concatenated strings:"+str1);

				
				
		//String tokenizer
		className = new String("UMN:CSCI:1933:Sec001");
		StringTokenizer st = new StringTokenizer(className,":");
		
		int count=1;
		while(st.hasMoreTokens()) {
			System.out.println(count+":"+st.nextToken());
			count++;
		}
		
		
	}
	
	
	
}