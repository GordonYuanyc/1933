/**
 * Example functions to display array indexing and searching in Java.
 */

public class ArrayIntroduction {
    /**
     * Call your functions here from the main method.
     * @param args
     */
    public static void main(String[] args) {
        int[] a = new int[]{5, 6, 7, 8, 9, 10, 1, 2, 3, 4};
        int arr[] = {10, 90, 49, 2, 1, 5, 23};
        everySecondNumber();

    }

    /**
     * This example shows an Array OutofBoundsException
      */
    public static void OutOfBoundsException() {
        int a[] = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        for (int i = 0; i <= 10; i++) {
            System.out.println("The index is " + i);
            System.out.println("The value of the element in the array is " + a[i]);
        }
    }

    /**
     * This example shows how to print every second number
     */
    public static void everySecondNumber() {
        int a[];
        a = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        for (int i = 0; i < 10; i += 2) {
            System.out.println("The index is " + i);
            System.out.println("The value of the element in the array is " + a[i]);
        }
    }

    public static void foreachDisplay(int[] data) {
        int a[] = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        System.out.println("Display an array using for each loop");
        for (Integer x : a) {
            System.out.print(x + " ");
        }
    }

    /**
     * This example demonstrates a for each in array of strings
     */
    public static void forEachStringArray() {
        String[] a = new String[]{"Hello", "Golden", "Gophers"};
        for (String string : a) {
            System.out.print(string + " ");
        }
    }

    /**
     * Set a[0] to 0. Set a[1...n] to 1.
     */
    public static void loopingOverArrays() {
        int a[] = new int[]{1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
        for (int i = 0; i < a.length; i++) {
            if (i == 0)
                a[i] = 0;
            else if (i == 1)
                a[i] = 1;
            else
                a[i] = a[i - 1];
        }

        for (int i = 0; i < a.length; i++) {
            System.out.println("The index is " + i + "and the value is " + a[i]);
        }
    }

    /**
     * Example to demonstrate passing array to a function.
     * @param a
     * @param x
     */
    public static void passingArray(int[] a, int x) {
        for (int i = 0; i < a.length; i++) {
            System.out.println("The array value is " + a[i]);
        }
        System.out.println("The value of x is " + x);
    }

    /**
     * Find the max element in an array.
     */
    public static void findMax() {
        int a[] = new int[]{23, 565, 21, 56, 22, 675, 123, 676, 87, 1000};
        int max = Integer.MIN_VALUE;
        for (int i = 0; i < a.length; i++) {
            max = Math.max(max, a[i]);
        }
        System.out.println("The max element is " + max);
    }

    /**
     * Linear search in an array.
     * @param a: The array to search in.
     * @param x: The search key.
     * @return The index of the key in the array. If the key doesn't exisit then it returns -1.
     */
    public static int linearSearch(int[] a, int x) {
        for (int i = 0; i < a.length; i++) {
            if (a[i] == x)
                return i;
        }
        return -1;
    }
}
