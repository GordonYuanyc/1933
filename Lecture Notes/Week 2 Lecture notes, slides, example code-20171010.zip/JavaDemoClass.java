import java.util.Scanner;
import java.io.*;



public class JavaDemoClass {

	public JavaDemoClass() {
		
	}
	
	public static void main(String[] args) {
		
		/*Scanner input = new Scanner(System.in);
		System.out.println("How many times?");
		int times = input.nextInt();
		for(int i=0; i < times; i++) {
			System.out.println("Hello world!");			
		}
		
		
		char symbol = '%';
		char letter;
		letter = 'A';*/
		
		/*int i,j;
		int k=10;
		i=5;
		j=j+5;	
		System.out.println(j);
		*/
		
		//int m,n=0;  //Careful-- m is only declared, not initialized!
		

		/*int p=0;
		double myDouble = p;

		int myInt;     //What's wrong here?
		myInt = 3.14159;*/

		//demoOperators();
		//demoIncDec();
		//operatorExample();
		//outputExample();
		inputExample();
		
		//divideExample();
		
	}
	
	
	
	public static void demoOperators() {
		
		//example from http://java.sun.com/docs/books/tutorial/java/nutsandbolts/op1.html
		System.out.println("Operator example");

		int result = 1 + 2; // result is now 3
        System.out.println(result);

        result = result - 1; // result is now 2
        System.out.println(result);

        result = result * 2; // result is now 4
        System.out.println(result);

        result = result / 2; // result is now 2
        System.out.println(result);

        result = result + 8; // result is now 10
        System.out.println(result);
        result = result % 7; // result is now 3
        System.out.println(result);
	}
	
	
	public static void demoIncDec() {
		System.out.println("Inc/Dec example");
		int j=10;
		int i=7;
		j++;
		i--;
		
		System.out.println(j);
		System.out.println(i);
		
		i=6;
		System.out.println((i++)*2);
		System.out.println("i:" + i);
		i=6;
		System.out.println((++i)*2);
		System.out.println("i:" + i);

		i=6;
		System.out.println(2*i++);
		System.out.println("i:" + i);
		
	}
	
	public static void operatorExample() {
		System.out.println("Operator Example:");
		int y=5;
		int x=1;
		y %= (++x);
		--y;

		System.out.println(x);
		System.out.println(y+1);
	}

	
	public static void divideExample() {
		
		int y=4;
		double x =  6.5/y;
		
		double z = 3/y;
		
		System.out.println(x);
		
		//Example from: https://alvinalexander.com/java/java-int-double-float-mixed-type-division-arithmetic-rules
		System.out.println("3 / 2     = " + (double)(3 / 2));
		System.out.println("3 / 2.0   = " + (3 / 2.0));
		System.out.println("3.0 / 2   = " + (3.0 / 2));
		System.out.println("3.0 / 2.0 = " + (3.0 / 2.0));
	}
	
	public static void outputExample() {
		System.out.println("Output Examples:");
		String myString = new String("Hello world");
		
		System.out.println(myString);
		System.out.println(myString+"--something extra");
		System.out.println(myString+"--Lucky number:"+13);
		System.out.println(myString+"--Lucky number:"+7+6);
		System.out.println(myString+"--Lucky number:"+(7+6));
		
		System.out.println();
		System.out.println();
		
		//what's the difference between print and println?
		System.out.print("This is ");
		System.out.println(" all on one line.");
		System.out.println("Next line.");
		

		try {
			File f = new File("myoutput.txt");
			PrintStream outfile = new PrintStream(f);
			outfile.println(myString+"--something extra");
			outfile.println(myString+"--Lucky number:"+13);
			outfile.println(myString+"--Lucky number:"+7+6);
			outfile.println(myString+"--Lucky number:"+(7+6));
		} catch(FileNotFoundException e) { System.out.println("Sorry, can't open file!"); System.exit(1); }
		
	}
	
	public static void inputExample () {
		
		Scanner keyboard = new Scanner (System.in);
	 
		System.out.println("Please enter your age:");
		int age = keyboard.nextInt();
	
		System.out.println("Please enter your name:");
		String name = keyboard.next();
		
		System.out.println("Name: "+name);
		System.out.println("Age: "+age);
		
		//Getting input from a text file
	    try {
	    	
	    	Scanner fileInput = new Scanner(new File("yeast_chr16_genomesequence.txt"));
		    String sequence = new String("");
			  
		    while (fileInput.hasNext()) {
		          sequence = sequence + fileInput.next();
		     }
		    
		    //System.out.println(sequence);
		    System.out.println("Yeast chromosome 16 has "+sequence.length()+" base pairs");
		    
		    } catch(FileNotFoundException e) { System.out.println("Sorry, can't find file!"); System.exit(1); }
	    

	}
}
