package planetwars.publicapi;

public interface IEdge {
    int getSourcePlanetId();

    int getDestinationPlanetId();

    int getLength();
}
